# Testbenches

1. Create a constant for every generic parameter in the DUT’s entity. You must also assign a value to
the constant, as it will be used to instantiate the DUT with the configuration we want to test. We
chose to implement a 4-bit adder.
2. Create a signal for every port in the DUT’s entity

**Switch from Implementation View to Simulation View**
**PICK TESTBENCH FOR SIMULATION** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

